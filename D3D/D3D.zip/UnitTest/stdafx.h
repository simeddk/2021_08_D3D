#pragma once

#include "Framework.h"
#pragma comment(lib, "../Debug/Framework.lib")

//#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")